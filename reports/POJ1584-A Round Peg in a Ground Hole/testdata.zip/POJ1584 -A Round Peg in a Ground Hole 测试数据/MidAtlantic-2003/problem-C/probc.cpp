#include <stdio.h>
#include <string.h>
#include <string>
#include <map>
#include <iostream>

using namespace std;

int main()
{
	map<string, int> db;
	string n;
	char buf[85], *cp;
	map<string, int>::iterator p;
	int max;
	int i;

	while (cin >> n) {
		strcpy(buf, n.c_str());
		cp = strtok(buf, ",.;\\'`\"()/:-");
		while (cp != NULL) {
			if (strlen(cp) != 0) {
				for (i = 0; i < strlen(cp); i++)
					cp[i] = (isalpha(cp[i]) ? tolower(cp[i]) : cp[i]);
				if (db.find(string(cp)) == db.end())
					db[string(cp)] = 1;
				else
					db[string(cp)]++;
			}
			cp = strtok(NULL, ",.;\\'`\"()/:-");
		}
	}

	max = -1;
	for (p = db.begin(); p != db.end(); p++) {
		if (p->second > max)
			max = p->second;
	}

	printf("%d occurrences\n", max);
	for (p = db.begin(); p != db.end(); p++) {
		if (p->second == max)
			printf("%s\n", p->first.c_str());
	}
	return 0;
}
		
