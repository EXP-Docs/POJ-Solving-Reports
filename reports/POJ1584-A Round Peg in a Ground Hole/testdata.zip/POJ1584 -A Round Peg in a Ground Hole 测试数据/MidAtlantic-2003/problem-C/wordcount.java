
import java.io.*;
import java.util.*;

public class wordcount {

  public static void main(String[] argv)
    throws Exception {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    Hashtable wordCounts = new Hashtable();

    String l = in.readLine();

    while(l!= null){
      StringTokenizer t = new StringTokenizer(l, " \t,.;\'`\"\\()/:-");
      while(t.hasMoreTokens()){
	String w = t.nextToken().toLowerCase();

	Integer count = (Integer)wordCounts.get(w);
	
	if (count == null)
	  count = new Integer(0);

	count = new Integer(count.intValue()+1);

	wordCounts.put(w, count);
      }

      l = in.readLine();
    }

    System.err.println(wordCounts);

    int maxCount = 0;
    for(Iterator doCosts = wordCounts.keySet().iterator();
	doCosts.hasNext();){
      int count = ((Integer)wordCounts.get(doCosts.next())).intValue();
      if (count > maxCount)
	maxCount = count;
    }

    System.out.println(maxCount +" occurrences");
    for(Iterator doCosts = wordCounts.keySet().iterator();
	doCosts.hasNext();){
      String word = (String) doCosts.next();
      int count = ((Integer)wordCounts.get(word)).intValue();

      if(count == maxCount)
	System.out.println(word);
    }
  }
}


