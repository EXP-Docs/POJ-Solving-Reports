import java.io.*;
import java.util.*;

public class Chem{
  public static void main (String[] argv)
  throws Exception {
    BufferedReader input = 
      new BufferedReader(new InputStreamReader(System.in));

    java.text.NumberFormat f = java.text.NumberFormat.getInstance();
    f.setMaximumFractionDigits(2);
    f.setMinimumFractionDigits(2);

    double prev = Double.parseDouble(input.readLine());
    double temp = Double.parseDouble(input.readLine());

    while (temp != 999){
      System.out.println(f.format(temp-prev));
      prev = temp;
      temp = Double.parseDouble(input.readLine());
    }
    
    System.out.println("End of Output");
  }
}
