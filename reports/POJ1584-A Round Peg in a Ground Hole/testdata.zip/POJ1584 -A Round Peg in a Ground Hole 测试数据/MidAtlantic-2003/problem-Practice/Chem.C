#include <stdio.h>

int main(){
  double t1,t2;

  scanf("%lf", &t1);
  scanf("%lf", &t2);
  
  while(t2!=999){
    printf ("%.2f\n", t2-t1);
    t1 = t2;
    scanf("%lf", &t2);
  }

  printf("End of Output\n");
}

    
