import java.io.*;
import java.util.*;

// what happens if there are no votes for any remaining candidate
// if more than one candidate, tie?
// if one, win?

public class runoff {

  public static void main(String[] argv)
    throws Exception {

    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    DATASET:
    while(true){
      String l = in.readLine();
      StringTokenizer t = new StringTokenizer(l);
      int nCandidates = Integer.parseInt(t.nextToken());
      int nBallots = Integer.parseInt(t.nextToken());
      
      if(nCandidates == 0)
	System.exit(0);

      Set candidates = new HashSet();
    
      Vector ballots = new Vector();

      for(int i=0;i<nBallots;i++){
	l = in.readLine().trim();
	Vector ballot = new Vector();
	t = new StringTokenizer(l);

	while(t.hasMoreTokens()){
	  String vote = t.nextToken();

	  candidates.add(vote);
	  ballot.add(vote);
	}
	ballots.add(ballot);
      }


      if(candidates.size()!=nCandidates)
	System.err.println("wrong number of candidates "+candidates.size()+
			   " != "+nCandidates);

      while(true){
	Hashtable votes = new Hashtable();

	System.err.println("the ballots are "+ballots);
	
	for(Iterator doCandidates = candidates.iterator();
	    doCandidates.hasNext();)
	  votes.put(doCandidates.next(), new Integer(0));
	
	for(Iterator doBallots = ballots.iterator();
	    doBallots.hasNext();){
	  Vector ballot = (Vector) doBallots.next();
	  String vote = (String) ballot.firstElement();
	  
	  Integer curCount = (Integer) votes.get(vote);
	  votes.put(vote, new Integer(1+curCount.intValue()));
	}

	System.err.println("the vote is "+votes);
	
	int minVote = Integer.MAX_VALUE;
	int minCount = 0;
	
	for(Iterator doVotes = votes.keySet().iterator();
	    doVotes.hasNext();){
	  String candidate = (String) doVotes.next();
	  
	  int thisVote = ((Integer)votes.get(candidate)).intValue();
	  if(thisVote > ballots.size()/2){
	    System.out.println(candidate+" won");
	    continue DATASET;
	  }
	  
	  if(thisVote < minVote){
	    minVote = thisVote;
	    minCount = 1;
	  }
	  else if(thisVote == minVote)
	    minCount++;
	}

	if(minCount == candidates.size()){
	  System.out.print("it is a tie between ");
	  for(Iterator doCandidates = candidates.iterator();
	      doCandidates.hasNext();){
	    System.out.print(doCandidates.next());
	    if (doCandidates.hasNext())
	      System.out.print(" and ");
	  }
	  System.out.println();
	  continue DATASET;
	}
	
	
	for(Iterator doVotes = votes.keySet().iterator();
	    doVotes.hasNext();){
	  
	  String candidate = (String) doVotes.next();
	  int thisVote = ((Integer)votes.get(candidate)).intValue();
	  
	  if(thisVote == minVote){
	    candidates.remove(candidate);
	    for(Iterator doBallots = ballots.iterator();
		doBallots.hasNext();){
	      Vector ballot = (Vector) doBallots.next();
	      ballot.remove(candidate);
	      if(ballot.size() == 0)
		doBallots.remove();
	    }
	  }
	}

	if(ballots.size() == 0){
	  if(candidates.size() == 1){
	    System.out.println(candidates.iterator().next()+" won");
	    continue DATASET;
	  }
	  System.out.print("it is a tie between ");
	  for(Iterator doCandidates = candidates.iterator();
	      doCandidates.hasNext();){
	    System.out.print(doCandidates.next());
	    if (doCandidates.hasNext())
	      System.out.print(" and ");
	  }
	  System.out.println();
	  continue DATASET;
	}
	  
      }
    }	
  }      
}
