#include <iostream>

/*
 * This solution implements a brute force approach which generates every
 * possible substring for the first sequence, and then for each one of these
 * substrings, it does a string::find() operation against the remaining
 * sequences. The solution runs in O(N^3) time where N is the total length
 * of all sequences.
 *
 * The most optimal solution would be to use suffix trees which can be built
 * and operated on in O(N) time.
 */

using namespace std;

/* Maximum number of sequences to compare in each data set */
#define MAXSEQ 10

/* Minimum length of common subsequences still considered "significant" */
#define MINSUBLEN 3

/*
 * Check if the subseq appears as a substring in any of the sequences in str[].
 * Since subseq is originally generated from str[0], it is not necessary to
 * check for a substring match on str[0]. Returns true if the subseq appears
 * in all sequences.
 */
bool compare(string const str[MAXSEQ], int str_num, string const &subseq)
{
    int str_idx;

    /* Perform a substring match against remaining sequences */
    for(str_idx = 1; str_idx < str_num; str_idx++) {
    
        /* Return false as soon as a substring search fails for any sequence */
        if(str[str_idx].find(subseq) == string::npos) {
            return false;
        }
    }
    
    /* The subsequence must appear in all sequence strings */
    return true;
}

/*
 * Generate every possible subsequence of str[0] and call compare() with each
 * subsequence to compare it against the remaining sequences in str[].
 */
string generate(string const str[MAXSEQ], int str_num)
{
    string::size_type const size = str[0].size();
    string longest;
    
    /*
     * Iterate over every possible substring length, including the full
     * string. Once we get under MINSUBLEN, we don't have to generate any
     * more substrings since any matches would not be considered relevant.
     */
    for(string::size_type len = size; len >= MINSUBLEN; len--) {
    
        /*
         * Iterate over every possible position in str[0] from which we can
         * generate a different substring of the given "len"
         */
        for(string::size_type pos = 0; pos <= size - len; pos++) {

            /* Current subsequence being considered */
            string subseq( str[0].substr(pos, len) );
        
            /* Check if this subsequence is common across all sequences */
            if(compare(str, str_num, subseq)) {
            
                /* If this is the longest subsequence found so far */
                if(subseq.size() > longest.size()) {
                    longest = subseq;
                }
                
                /* Or if the same length but alphabetically comes first */
                else if(subseq.size() == longest.size() && subseq < longest) {
                    longest = subseq;
                }
            }
        }
    }
    
    /* Return the longest subsequence found */
    return longest;
}

/* Main body of program */
void process(void)
{
    string str[MAXSEQ];
    int data_num, data_idx;

    /* Read how many data sets to process */
    cin >> data_num;
    
    /* Process each data set separately */
    for(data_idx = 0; data_idx < data_num; data_idx++) {
        int str_num, str_idx;
    
        /* Read how many DNA sequences to parse */
        cin >> str_num;

        /* Read in each DNA sequence into string array */
        for(str_idx = 0; str_idx < str_num; str_idx++) {
            cin >> str[str_idx];
        }

        /* Search for the longest common subsequence */
        string subseq( generate(str, str_num) );

        /* Print the longest subsequence if found */
        if(subseq.size()) {
            cout << subseq << endl;
        } else {
            cout << "no significant commonalities" << endl;
        }
    }
}

/* Run program and print out any exceptions that occur */
int main(void)
{
    /* Throw exceptions on EOF or failed data extraction in >> operator */
    cin.exceptions(ios::eofbit | ios::failbit);

    /* Run main body of code */
    try {
        process();
    }
    
    /* Catch any internally generated exceptions */
    catch(char const *e) {
        cerr << "Exception: " << e << endl;
    }
    
    /* Catch unexpected EOF or bad input data */
    catch(ios::failure const &e) {
        cerr << "Unexpected EOF or data type mismatch on input" << endl;
    }

    return 0;
}
